var settings = {};

function getProjectListURL () {
	var tempURL;
	var env = getEnvironment();
	if (magIsEnabled() == "true") {
		if (env == "pub") {
			tempURL = "http://w3m-alpha.huawei.com/mcloud/mag/ProxyForText/mcloud_ide_pub/services/mcloud/ide/project/list/2999/1";
		} else if (env == "pub2") {
			tempURL = "http://w3m-beta.huawei.com/mcloud/mag/ProxyForText/mcloud_ide_pub2/services/mcloud/ide/project/list/2999/1";
		} else if (env == "unicom") {
			tempURL = "http://haepub-gw.huawei.com/mcloud/umag/fg/ProxyForDownLoad/mcloudIDE_uc/services/mcloud/ide/project/list/2147483647/1";
		} else if (env == "uat") {
			tempURL = "http://w3m-beta2.huawei.com/mcloud/mag/ProxyForText/mcloud_ide_uat/services/mcloud/ide/project/list/2999/1";
		} else if (env == "sit") {
			tempURL = "http://w3m-alpha2.huawei.com/mcloud/mag/ProxyForText/mcloud_ide_sit/services/mcloud/ide/project/list/2999/1";
		} else if (env == "dev") {
			tempURL = "http://w3m-alpha2.huawei.com/mcloud/mag/ProxyForText/mcloud_ide_dev/services/mcloud/ide/project/list/2999/1";
		}
	} else {
		if (env == "pub") {
			tempURL = "http://mcloud-pub.huawei.com/mcloud/ide/services/mcloud/ide/project/list/2999/1";
		} else if (env == "pub2") {
			tempURL = "http://mcloud-pub2.huawei.com/mcloud/ide/services/mcloud/ide/project/list/2999/1";
		} else if (env == "unicom") {
			tempURL = "http://haepub-gw.huawei.com/mcloud/umag/fg/ProxyForDownLoad/mcloudIDE_uc/services/mcloud/ide/project/list/2147483647/1";
		} else if (env == "uat") {
			tempURL = "http://mcloudnkg-uat1.huawei.com/mcloud/ide/services/mcloud/ide/project/list/2999/1";
		} else if (env == "sit") {
			tempURL = "http://mcloudnkg-sit.huawei.com/mcloud/ide/services/mcloud/ide/project/list/2999/1";
		} else if (env == "dev") {
			tempURL = "http://nkweb-sit.huawei.com/mcloud/ide/services/mcloud/ide/project/list/2999/1";
		}
	}
	return tempURL;
}


function getProjectURL (projectId) {
	var tempURL;
	var env = getEnvironment();
	if (magIsEnabled() == "true") {
		if (env == "pub") {
			tempURL = "http://w3m-alpha.huawei.com/mcloud/mag/ProxyForText/mcloud_ide_pub/services/mcloud/ide/project/single/derivation/binaries/";
		} else if (env == "pub2") {
			tempURL = "http://w3m-beta.huawei.com/mcloud/mag/ProxyForText/mcloud_ide_pub2/services/mcloud/ide/project/single/derivation/binaries/";
		} else if (env == "unicom") {
			tempURL = "http://haepub-gw.huawei.com/mcloud/umag/fg/ProxyForDownLoad/mcloudIDE_uc/services/mcloud/ide/project/single/derivation/binaries/";
		} else if (env == "uat") {
			tempURL = "http://w3m-beta2.huawei.com/mcloud/mag/ProxyForText/mcloud_ide_uat/services/mcloud/ide/project/single/derivation/binaries/";
		} else if (env == "sit") {
			tempURL = "http://w3m-alpha2.huawei.com/mcloud/mag/ProxyForText/mcloud_ide_sit/services/mcloud/ide/project/single/derivation/binaries/";
		} else if (env == "dev") {
			tempURL = "http://w3m-alpha2.huawei.com/mcloud/mag/ProxyForText/mcloud_ide_dev/services/mcloud/ide/project/single/derivation/binaries/";
		}
	} else {
		if (env == "pub") {
			tempURL = "http://mcloud-pub.huawei.com/mcloud/ide/services/mcloud/ide/project/single/derivation/binaries/";
		} else if (env == "pub2") {
			tempURL = "http://mcloud-pub2.huawei.com/mcloud/ide/services/mcloud/ide/project/single/derivation/binaries/";
		} else if (env == "unicom") {
			tempURL = "http://haepub-gw.huawei.com/mcloud/umag/fg/ProxyForDownLoad/mcloudIDE_uc/services/mcloud/ide/project/single/derivation/binaries/";
		} else if (env == "uat") {
			tempURL = "http://mcloudnkg-uat1.huawei.com/mcloud/ide/services/mcloud/ide/project/single/derivation/binaries/";
		} else if (env == "sit") {
			tempURL = "http://mcloudnkg-sit.huawei.com/mcloud/ide/services/mcloud/ide/project/single/derivation/binaries/";
		} else if (env == "dev") {
			tempURL = "http://nkweb-sit.huawei.com/mcloud/ide/services/mcloud/ide/project/single/derivation/binaries/";
		}
	}
	return tempURL + projectId;
}

function getIndentifier (userName) {
	if (typeof userName === 'string') {
		if (userName.length) {
			var tempValue = userName + '_mcloud';
			return tempValue;
		} else {
			return "default";
		}
	} else {
		return "default";
	}
}

function getEnvironment(){
	var env = mcloud.getLocalConfig('environment', 'uat');
	mcloud.log("------current environment:"+env);
	return env;
}

function magIsEnabled(){
	var enableMag =  mcloud.getLocalConfig('enableMAG', "true");
	mcloud.log("------isMAGEnabled:"+enableMag);
	return enableMag;
}


settings.getProjectListURL = getProjectListURL;

settings.getProjectURL = getProjectURL;

settings.env = getEnvironment();

settings.getIndentifier = getIndentifier;

settings.isMAGEnabled = magIsEnabled();

var exports = settings;