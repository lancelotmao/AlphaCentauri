console.log('loading t1.js');

var global = 1;

var exports = {
	test : function() {
	    return "test1";
	},

	getGlobal : function() {
		return global++;
	},

	reset : function() {
		global = 1;
	}
};