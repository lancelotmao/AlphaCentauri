(function(){
console.log('starting mcloud...');

// we will restart app automatically after refresh
function refresh() {
	var refresher = require('./refresh');
	refresher.downloadProject(mcloud.getProjectId(), function(result){
		mcloud.widget.dismissLoading();
		if (result) {
			mcloud.showToast("更新项目成功！", '0');
			mcloud.restart();
		} else {
			console.log('更新项目失败！');
			mcloud.showToast("更新项目失败！", '0');
		}
	});
}

function onLoginClicked(uid, pwd) {
	if ( !(uid && pwd) ) {
		return;
	}

	console.log(uid);
	console.log(pwd);

	var identifier = require('settings').getIndentifier(uid);
	console.log(identifier);

	console.log("logining....");

	var loginBundle = require("login.js");
	console.log(loginBundle);
	mcloud.widget.showLoading(null);
	loginBundle.login({
	  username:uid,
	  password:pwd,
	  identifier:identifier,
	  success: function(result, status) {
	    mcloud.setLocalConfig('mcloudplay_userName', uid);
		mcloud.setLocalConfig('mcloudplay_password', pwd);
		console.log('登陆成功！');
		mcloud.showToast('登陆成功！', '0');
		mcloud.hideLoginDialog();

	    // start refreshing immediately
	    refresh();
	  },
	  error: function(status, error) {
	  	mcloud.widget.dismissLoading();
	    console.log('登陆失败！' + error);
	    mcloud.showToast(error, '0');
	  },
	});
}

function onFloatingViewClick() {
	var userName = mcloud.getLocalConfig('mcloudplay_userName', '');
	console.log('userName is: ' + userName);
    var password = mcloud.getLocalConfig('mcloudplay_password', '');
	if (userName == 'undefined' || userName == null || userName == '') {
		mcloud.showLoginDialog(onLoginClicked);
	} else {
		mcloud.widget.showLoading(null);
		refresh();
	}
}
var floatingView = mcloud.createFloatingAssistant();
floatingView.setLongClickHandler(onFloatingViewClick);
floatingView.setClickHandler(onFloatingViewClick);
floatingView.show();
})();