console.log('loading login mcloud play.');

var loginBundle = {};
var tag;

// mark: ------ register
function register (argument) {

    var uid = argument.username;
    var pwd = argument.password;

    var successCallback = argument.success;
    var errorCallback = argument.error;

    var env = mcloud.getLocalConfig('environment', 'uat');

    var requestURL  = getRequestURL("DevRegister", env);
    var requestBody = getRequestBody(uid, pwd, env);

    $.ajax({
        url : requestURL,
        async : true,
        type : "POST",
        data : requestBody,
        timeout : 30000,
        beforeSend : function(xhr) {
            console.log("register before send callback ....");
            setRequestHeader(uid, xhr, env);
        },
        complete :function(xhr, status) {
            console.log("register complete status code is " + status);
        },
        success :function(result , status, xhr) {
            console.log("register success callback");
            console.log(result);

            //TODO:注意try catch
            // var obj = JSON.parse(result);
            //用户类型 obj.MagUserType
            //证书 obj.jsonDevCert
            // console.log("lucaiguang" + obj.MagUserType);
            // var cert = JSON.parse(obj.jsonDevCert);
            // console.log("lucaiguang - " + cert.cert);
            // console.log("lucaiguang - " + cert.validTime);
            // console.log("lucaiguang - " + cert.password);
            // console.log("lucaiguang - " + cert.flag);
            // console.log("lucaiguang - " + cert.serialNumber);
            // console.log("lucaiguang - " + cert.certType);

            var obj;

            try {
                obj = JSON.parse(result);
            } catch(e) {
                obj = null;
            }

            if (obj.jsonDevCert) {
                console.log("register success.");
                successCallback(status, "{'success':'success'}");
            } else {
                console.log("register failed.");
                errorCallback(status, result);
            }
        },
        error :function(xhr , status, error) {
            console.log("errorCallback: error = " + error);
            errorCallback(status, error);
        }
    });
}

// mark: ------ login
function login (argument) {
    var uid = argument.username;
    var pwd = argument.password;

    var successCallback = argument.success;
    var errorCallback   = argument.error;

    var identifier = argument.identifier;
    if (!identifier) {
        identifier = "default";
    }

    var env = mcloud.getLocalConfig('environment', 'uat');

    if (needRegister(uid, identifier, env)) {
        register({
            username : uid,
            password : pwd,
            success  : function (status, info) {
                setKeyChainInfo(uid, identifier, env);
                login(argument);
            },
            error    : function (status, error) {
                var obj;

                try {
                    obj = JSON.parse(error);
                } catch(e) {
                    obj = null;
                }

                if (obj) {
                    errorCallback(status, obj.errorMessage);
                } else {
                    errorCallback(status, error);
                }
            }
        });
        return;
    }

    var requestURL  = getRequestURL("Login", env);
    var requestBody = getRequestBody(uid, pwd, env);

    $.ajax({
        url : requestURL,
        async : true,
        type : "POST",
        data : requestBody,
        timeout : 30000,
        beforeSend : function (xhr) {
            console.log("login before send callback .....");
            setRequestHeader(uid, xhr, env);
        },
        complete : function (xhr, status) {
            console.log("login complete status code is " + status);
        },
        success : function (result, status, xhr) {
            console.log("login success callback.");
            
            console.log(result);

            var obj;

            try {
                obj = JSON.parse(result);
            } catch(e) {
                obj = null;
            }

            if (obj.login == "successed") {
                console.log("login success.");
                //保存Cookies
                xhr.saveCookies(identifier);

                //保存用户密码
                mcloud.setLocalConfig('mcloudplay_userName', uid);
                mcloud.setLocalConfig('mcloudplay_password', pwd);

                //保存登陆时间
                successCallback(obj.login, status);
            } else {
                console.log("login failed.");
                if (obj.errorMessage) {
                    errorCallback(status, obj.errorMessage);
                } else {
                    errorCallback(status, result);
                }
            }
        },
        error : function (xhr, status, error) {
            console.log("login error callback .....");
            console.log("ERROR: " + error);
        }
    });

}

function autoLogin (argument) {

    var beforeSendCallback = argument.beforeSend;
    var successCallback = argument.success;
    var errorCallback = argument.error;

    var uid = mcloud.getLocalConfig('mcloudplay_userName', '');
    var pwd = mcloud.getLocalConfig('mcloudplay_password', '');

    var identifier = require('./settings').getIndentifier(uid);

    if (beforeSendCallback) {
        beforeSendCallback();
    };

    var autoLoginArgument = {
        username : uid,
        password : pwd,
        identifier : identifier,
        success : successCallback,
        error : errorCallback
    };

    login(autoLoginArgument);
}


// mark: ------ utility
function needRegister (username, identifier, enviroment) {
    var oldUsername = getKeyChainInfo(identifier, enviroment);
    console.log("++++++++++++++++++++");
    console.log("oldUsername = " + oldUsername + ", username = " + username);
    console.log("++++++++++++++++++++");
    if (oldUsername == username) {
        return false;
    }
    return true;
}

function getKeyChainInfo (identifier, enviroment) {
    if (!tag) {
        tag = "default";
    }
    var key = tag + "_" + enviroment;//identifier + "_" + enviroment;
    var keychain = new KeyChain();
    var username = keychain.get(key);
    return username;
}

function setKeyChainInfo (username, identifier, enviroment) {
    if (!tag) {
        tag = "default";
    }
    var key = tag + "_" + enviroment;//identifier + "_" + enviroment;
    var keychain = new KeyChain();
    keychain.save(key, username);
}

function setRequestHeader (username, xhr, enviroment) {
    var acceptLanguage = xhr.getAcceptLanguage();
    var ip = xhr.getIPAddress();
    var operator = xhr.getOperator();
    var networkType = xhr.getNetworkState();

    var sessionKey;

    if (enviroment == "unicom") {
        var publicKey = getPublickey(enviroment);
        var rsa = new Crypt.RSA();
        sessionKey = rsa.encode(publicKey, username);
    } else {
        sessionKey = "aRIyNxmMSDEj7lWBwY0a9bve+AyMbeM7PhxOBlpDL/J0HuLUI2JAepTP/FIkWWbSzctMETVK52DUAI2ArI2RRuRqqhDMYCuc/959hxcYg7agHB8VGR2UD4tu0d70yUvBFlKRFsiZPkkqkbw45QB50lSVeoj1Ah5hROLq6IIOsyQ=";
    }

    console.log("sessionKey=========="+sessionKey);
    
    xhr.setRequestHeader("sessionKey", sessionKey);
    xhr.setRequestHeader("Accept-Language", acceptLanguage);
    xhr.setRequestHeader("network",networkType);
    xhr.setRequestHeader("sp",operator);
    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    xhr.setRequestHeader("ip",ip);
    xhr.setRequestHeader("bundleVersion","1.1.2");
    xhr.setRequestHeader("bundleName","LoginBundle");
}

function getPublickey (enviroment) {
    if (enviroment == "pub" || enviroment == "pub2" || enviroment == "unicom") {
        return "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDGZ8X4L60JTz2nhNhJPcnLSguN+mJsm/UOZIU8fKY2OI7K6WRMfNC2U7hStea6uoVPmcAXixMhKm6l3Aa7yK5crxE4rw9NkBmz1JDJa0X0k1yUWucDgz9XxpJsQQ0Alm3hmOSPnZM5ZmcJfm+yEAoc+9fNfZ2FBA3g69vlgWe7YwIDAQAB";
    } else {
        return "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDbf3N5eW+PgmaLBvDE23uMjdJW/eTrT8Hrx/fUvPcgeCoGqP8czJkFy2/XtDfWzaQJ1crPZTU/jGPPUIYeG7bWM61UHsMvDFos8F/RJhnreYML52MwRE55aD8AC0UOs0UxGBtT0ByG874qM8nOanN2Homy/hsJjj/HzQZuQ/vWUQIDAQAB";
    }
}

function getRequestURL (port, enviroment) {
    if (enviroment == "pub") {
        return "http://w3m-alpha.huawei.com/mcloud/mag/" + port;
    } else if (enviroment == "pub2") {
        return "http://w3m-beta.huawei.com/mcloud/mag/" + port;
    } else if (enviroment == "unicom") {
        return "http://haepub-gw.huawei.com/mcloud/umag/" + port;
    } else if (enviroment == "uat") {
        return "http://w3m-beta2.huawei.com/mcloud/mag/" + port;
    } else if ((enviroment == "sit") || (enviroment == "dev")) {
        return "http://w3m-alpha2.huawei.com/mcloud/mag/" + port;
    }
}

function getRequestBody (username, password, enviroment) {
    var publicKey = getPublickey(enviroment);
    var rsa = new Crypt.RSA();
    var rsaUID = rsa.encode(publicKey, username);
    var rsaPwd = rsa.encode(publicKey, password);

    var encodeRsaUID = encodeURIComponent(rsaUID);
    var encodeRsaPwd = encodeURIComponent(rsaPwd);

    return "uid="+encodeRsaUID+"&"+"password="+encodeRsaPwd;
}

function setTag (argument) {
    if (typeof argument == 'string') tag = argument;
}

loginBundle.autoLogin = autoLogin;
loginBundle.login = login;
loginBundle.setTag = setTag;
loginBundle.register = register;

var exports = loginBundle;