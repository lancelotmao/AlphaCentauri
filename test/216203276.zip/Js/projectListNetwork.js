var network = {};

function downloadProjectList (identifier ,callback) {
	var projectListURL = require('./settings').getProjectListURL();
	console.log("downloadProjectList: projectListURL = " + projectListURL);
    if (!identifier) {
      identifier = "default";
    }
    $.ajax({
       url :projectListURL,
       cache : true,  //default is false.
       async : true, //default is true.
       type : "GET", //default is get.
       timeout : 30000, // 30 seconds
       identifier : identifier,
       contentType : "application/x-www-form-urlencoded", //default is "application/x-www-form-urlencoded"
       beforeSend : function beforeSend(xhr){
           xhr.setRequestHeader("bundleVersion","1.1.2");
           xhr.setRequestHeader("publicKeyFlag","0");
           xhr.setRequestHeader("bundleName","LoginBundle");
           console.log("beforeSend");
       },
       complete :function(xhr, status) {
           console.log("complete: status = " + status);
       },
       success :function(result , status, xhr) {
           console.log("success: result = " + result);
           callback(null, result);
       },
       error :function(xhr , status, error) {
           console.log("error: status = " + status);
           callback(error, null);
       },
	});
}

network.downloadProjectList = downloadProjectList;

var exports = network;