var rambo = require('rambo');

function test1() {
  var loginBundle = require("login.js");
  loginBundle.login({
      username:'test1',
      password:'Pr0d1234',
      success:function(result, status){
        var identifier =  mcloud.getPageParam().identifier;
        require('./network').downloadProjectList(identifier ,function(err, result) {
          if (err) {
            console.log("downloadProjectList: failed...........");
            return;
          }

          var resultParse;

          try {
            resultParse = JSON.parse(result);
            var list = resultParse.result;
            if(list.length > 0) {
              rambo.pass('ProjectList Obtain success');
            } else {
              rambo.fail('ProjectList Obtain failed');
            }
          } catch(e) {
            resultParse = null;
            rambo.fail('ProjectList Obtain failed');
          }
        });
      },
      error:function(status, error){
        rambo.fail('login normal fail');
      }
  });
}


var exports = [test1];