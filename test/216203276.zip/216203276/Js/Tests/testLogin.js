var rambo = require('rambo');

function test1() {
  var loginBundle = require("login.js");
  loginBundle.login({
      username:'test1',
      password:'Pr0d1234',
      success:function(result, status){
        rambo.pass('login normal OK');
      },
      error:function(status, error){
        rambo.fail('login normal fail');
      }
  });
}

function test2() {
  var loginBundle = require("login.js");
  loginBundle.login({
      username:'test',
      password:'Pr0d12345',
      success:function(result, status){
        rambo.fail('login normal OK');
      },
      error:function(status, error){
        // if (error == '500') {
          rambo.pass('login incorrect password OK')
        // } else {
        //   fail('login incorrect password fail');
        // }
      }
  });
}

function test3() {
  var loginBundle = require("login.js");
  loginBundle.login({
      username:'test1',
      password:'Pr0d12345',
      success:function(result, status){
        rambo.fail('login normal OK');
      },
      error:function(status, error){
        rambo.pass('login incorrect password OK')
      }
  });
}

function test4() {
  var loginBundle = require("login.js");
  loginBundle.login({
      username:'test',
      password:'Pr0d1234',
      success:function(result, status){
        rambo.fail('login normal OK');
      },
      error:function(status, error){
          rambo.pass('login incorrect password OK')
      }
  });
}

function test5() {
  var loginBundle = require("login.js");
  loginBundle.login({
      username:'test1',
      password:'Pr0d12345',
      success:function(result, status){
        rambo.fail('login normal OK');
      },
      error:function(status, error){
          rambo.pass('login incorrect password OK')
      }
  });
}

var exports = [test1, test2,test3,test4,test5];