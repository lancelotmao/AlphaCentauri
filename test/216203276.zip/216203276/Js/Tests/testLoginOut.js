var rambo = require('rambo');

function test1() {
 var loginBundle = require("login.js");
   loginBundle.login({
       username:'test1',
       password:'Pr0d1234',
       success:function(result, status){

            mcloud.setLocalConfig("loginSuccess", "true");
            mcloud.core.finishPage();
            rambo.success('loginout normal success');
       },
       error:function(status, error){
         mcloud.setLocalConfig("loginSuccess", "false");
         rambo.fail('loginout normal fail');
       }
   });
}

function test2() {
 var loginBundle = require("login.js");
   loginBundle.login({
       username:'test1',
       password:'Pr0d1234',
       success:function(result, status){
            if(fromWhere != "loginPage"){
              mcloud.startPage("loginPage");
            }
            mcloud.setLocalConfig("loginSuccess", "false");
            mcloud.core.finishPage();
            loginBundle.login({
                   username:'test1',
                   password:'Pr0d1234',
                   success:function(result, status){
                   rambo.success('loginout normal success');
                   }

                   }
       },
       error:function(status, error){
         rambo.fail('loginout normal fail');
       }
   });
}

var exports = [test1, test2];