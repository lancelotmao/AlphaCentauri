var refreshProject = {};
refreshProject.widgetDemo = "widgetDemo";
refreshProject.bundleDemo = "bundleDemo";
refreshProject.gettingStartDemo = "gettingStartDemo";

var isMAGEnabled = mcloud.getLocalConfig('enableMAG', "true");

function downloadProject (projectId, callback) {
	console.log('Refresh Project...');
	console.log(projectId);

	var URLObject = getDownloadURLObject(projectId);
	var http = require("http");

	var identifier = mcloud.getLocalConfig("playIdentifier", "default");

    var options = {
        hostname: URLObject.hostname,
        port: URLObject.port,
        path: URLObject.path,
        identifier : identifier,
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'bundleVersion': '1.1.2',
            'publicKeyFlag':'0',
            'bundleName':'LoginBundle'
        }
    };
    
    var fs = require("fs");
    var srcFilePath = "~/project.zip";
    var destFilePath = "~/Projects/" + projectId;
    var writeFs = fs.createWriteStream(srcFilePath);
    var req = http.get(options, function(res) {
                mcloud.log('STATUS: ' + res.statusCode);
                mcloud.log('HEADERS: ' + JSON.stringify(res.headers));
                res.pipe(writeFs);
                res.on("end",function(e){
                	if(e){
                		mcloud.log("failed to pipe stream.");
                		return;
                	}
                	var result = mcloud.unzip(srcFilePath, destFilePath);
					if (!result) {
						var text = fs.readFileSync(srcFilePath, "utf8");
						mcloud.log("lucaiguang +++++ " + text);

			            var obj;

			            try {
			                obj = JSON.parse(result);
			            } catch(e) {
			                obj = null;
			            }

			            if (obj && (obj.errorCode == "1000")) {
			                var temp = require("./login.js");
			                temp.setTag("mcloud");
			                temp.autoLogin({
			                    success:function (argument) {
			                        refreshProject();
			                    }
			                });
			            }
						//{"errorMessage":"请使用w3账号登录。","errorCode":"1000"}
					}
					callback(result);
                })
              });
    
    req.on('error', function(e) {
        mcloud.log('problem with request: ' + e.message);
    });
    req.end();
}

function getDownloadURLObject (projectId) {
	var env = mcloud.getLocalConfig('environment', 'uat');
	var isMAGEnabled = mcloud.getLocalConfig('enableMAG', "true");

	var tempHostName;
	var tempPath;
	var tempPort;

	if (isMAGEnabled) {
		if (env == "pub") {
			tempHostName = "http://w3m-beta.huawei.com";
			tempPath = "/mcloud/mag/fg/ProxyForDownLoad/mcloudIDE_pub2/services/mcloud/ide/project/single/derivation/binaries/";
			tempPort = 80;
		} else if (env == "uat") {
			tempHostName = "http://w3m-beta2.huawei.com";
			tempPath = "/mcloud/mag/fg/ProxyForDownLoad/mcloud_ide_uat/services/mcloud/ide/project/single/derivation/binaries/";
			tempPort = 80;
		} else if (env == "unicom") {
			tempHostName = "http://haepub-gw.huawei.com";
			tempPath = "/mcloud/umag/fg/ProxyForDownLoad/mcloudIDE_uc/services/mcloud/ide/project/single/derivation/binaries/";
			tempPort = 80;
		} else {
			tempHostName = "http://w3m-alpha2.huawei.com";
			tempPath = "/mcloud/mag/fg/ProxyForDownLoad/mcloud_ide_sit/services/mcloud/ide/project/single/derivation/binaries/";
			tempPort = 80;
		}
	} else {
		if (env == "pub") {
			tempHostName = "http://mcloud-pub2.huawei.com";
			tempPath = "/mcloud/ide/services/mcloud/ide/project/single/derivation/binaries/";
			tempPort = 80;
		} else if (env == "uat") {
			tempHostName = "http://mcloudnkg-uat1.huawei.com";
			tempPath = "/mcloud/ide/services/mcloud/ide/project/single/derivation/binaries/";
			tempPort = 80;
		} else if (env == "dev") {
			tempHostName = "http://mcloud-dev.huawei.com";
			tempPath = "/mcloud/ide/services/mcloud/ide/project/single/derivation/binaries/";
			tempPort = 80;
		} else if (env == "unicom") {
			tempHostName = "http://haepub-gw.huawei.com";
			tempPath = "/mcloud/umag/fg/ProxyForDownLoad/mcloudIDE_uc/services/mcloud/ide/project/single/derivation/binaries/";
			tempPort = 80;
		} else {
			tempHostName = "http://mcloudnkg-sit.huawei.com";
			tempPath = "/mcloud/ide/services/mcloud/ide/project/single/derivation/binaries/";
			tempPort = 80;
		}
	}

	var fullPath = tempPath + projectId;

	var returnValue = new Object();
	returnValue.hostname = tempHostName;
	returnValue.path = fullPath;
	returnValue.port = tempPort;

	return returnValue;
}

function downloadDemo(demoType, callback) {
	console.log('downloadDemo：demoType = ' + demoType);

	var demoURLObject = getDownloadDemoURLObject(demoType);
	var http = require("http");

	var identifier = mcloud.getLocalConfig("playIdentifier", "default");

    var options = {
        hostname: demoURLObject.hostname,
        port: demoURLObject.port,
        path: demoURLObject.path,
        identifier : identifier,
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'bundleVersion': '1.1.2',
            'publicKeyFlag':'0',
            'bundleName':'LoginBundle'
        }
    };

    var fs = require("fs");
	var srcFilePath = "~/Projects/" + demoType + ".zip";
	var destFilePath = "~/Projects/" + demoType;
	mcloud.log(srcFilePath);
    var writeFs = fs.createWriteStream(srcFilePath);
    var req = http.get(options, function(res) {
                mcloud.log('STATUS: ' + res.statusCode);
                mcloud.log('HEADERS: ' + JSON.stringify(res.headers));
                res.pipe(writeFs);
                res.on("end",function(e){
                	if(e){
                		mcloud.log("failed to pipe stream.");
                		return;
                	}
                	var result = mcloud.unzip(srcFilePath, destFilePath);
					if (!result) {
						var text = fs.readFileSync(srcFilePath, "utf8");
						mcloud.log("lucaiguang +++++ " + text);

			            var obj;

			            try {
			                obj = JSON.parse(result);
			            } catch(e) {
			                obj = null;
			            }

			            if (obj && (obj.errorCode == "1000")) {
			                var temp = require("./login.js");
			                temp.setTag("mcloud");
			                temp.autoLogin({
			                    success:function (argument) {
			                        refreshProject();
			                    }
			                });
			            }
						//{"errorMessage":"请使用w3账号登录。","errorCode":"1000"}
					}
					callback(destFilePath);
                })
              });

    req.on('error', function(e) {
        mcloud.log('problem with request: ' + e.message);
    });
    req.end();
}

function getDownloadDemoURLObject (demoType) {
	var env = mcloud.getLocalConfig('environment', 'uat');

	var tempHostName;
	var tempPath;
	var tempPort;
    if (isMAGEnabled) {
		if (demoType == refreshProject.widgetDemo) {
		    tempHostName = "http://w3m-alpha.huawei.com";
			tempPath = "/mcloud/mag/FreeProxyForText/mamservice/rest/downLoad/bundleByName/WidgetDemo/2";
		} else if (demoType == refreshProject.bundleDemo) {
		    tempHostName = "http://w3m-alpha.huawei.com";
			tempPath = "/mcloud/mag/FreeProxyForText/mamservice/rest/downLoad/bundleByName/BundleDemo1/2";
		} else if (demoType == refreshProject.gettingStartDemo) {
		    tempHostName = "http://w3m-alpha.huawei.com";
			tempPath = "/mcloud/mag/FreeProxyForText/mamservice/rest/downLoad/bundleByName/GettingStartDemo1/2";
		}
	} else {
		if (demoType == refreshProject.widgetDemo) {
		    tempHostName = "http://w3m-alpha.huawei.com";
			tempURL = "/mcloud/mag/FreeProxyForText/mamservice/rest/downLoad/bundleByName/WidgetDemo/2";
		} else if (demoType == refreshProject.bundleDemo) {
		    tempHostName = "http://w3m-alpha.huawei.com";
			tempPath = "/mcloud/mag/FreeProxyForText/mamservice/rest/downLoad/bundleByName/BundleDemo1/2";
		} else if (demoType == refreshProject.gettingStartDemo) {
		    tempHostName = "http://w3m-alpha.huawei.com";
			tempPath = "/mcloud/mag/FreeProxyForText/mamservice/rest/downLoad/bundleByName/GettingStartDemo1/2";
		}
	}
	var returnValue = new Object();
	returnValue.hostname = tempHostName;
	returnValue.path = tempPath;
	returnValue.port = "80";
	return returnValue;
}

function getDemoURL(demoType) {
	var tempURL;
	if (isMAGEnabled) {
		if (demoType == refreshProject.widgetDemo) {
			tempURL = "http://w3m-alpha.huawei.com/mcloud/mag/FreeProxyForText/mamservice/rest/downLoad/bundleByName/WidgetDemo/2";
		} else if (demoType == refreshProject.bundleDemo) {
			tempURL = "http://w3m-alpha.huawei.com/mcloud/mag/FreeProxyForText/mamservice/rest/downLoad/bundleByName/BundleDemo1/2";
		} else if (demoType == refreshProject.gettingStartDemo) {
			tempURL = "http://w3m-alpha.huawei.com/mcloud/mag/FreeProxyForText/mamservice/rest/downLoad/bundleByName/GettingStartDemo1/2";
		}
	} else {
		if (demoType == refreshProject.widgetDemo) {
			tempURL = "http://w3m-alpha.huawei.com/mcloud/mag/FreeProxyForText/mamservice/rest/downLoad/bundleByName/WidgetDemo/2";
		} else if (demoType == refreshProject.bundleDemo) {
			tempURL = "http://w3m-alpha.huawei.com/mcloud/mag/FreeProxyForText/mamservice/rest/downLoad/bundleByName/BundleDemo1/2";
		} else if (demoType == refreshProject.gettingStartDemo) {
			tempURL = "http://w3m-alpha.huawei.com/mcloud/mag/FreeProxyForText/mamservice/rest/downLoad/bundleByName/GettingStartDemo1/2";
		}
	}
	return tempURL;
}

function downloadDemos(callback) {
    var fs = require("fs");
    var srcFilePath = "~/Projects/" + refreshProject.widgetDemo + ".zip";;
	fs.exists(srcFilePath, function(exists) {
		if (exists) {
			console.log("downloadDemo: demo exists");
			fs.unlinkSync(srcFilePath);
		} else{
		    downloadDemo(refreshProject.widgetDemo, callback);
		}
	});

    fs.exists(srcFilePath, function(exists) {
        if (exists) {
            console.log("downloadDemo: demo exists");
            fs.unlinkSync(srcFilePath);
        } else{
            downloadDemo(refreshProject.bundleDemo, callback);
        }
    });

	srcFilePath = "~/Projects/" + refreshProject.gettingStartDemo + ".zip";;
    fs.exists(srcFilePath, function(exists) {
        if (exists) {
            console.log("downloadDemo: demo exists");
            fs.unlinkSync(srcFilePath);
        } else{
            downloadDemo(refreshProject.gettingStartDemo, callback);
        }
    });
}

refreshProject.downloadProject = downloadProject;
refreshProject.downloadDemo = downloadDemo;
refreshProject.downloadDemos = downloadDemos;

var exports = refreshProject;