var cache = {};

function getProjectListCache(callback) {
    var uid = mcloud.getLocalConfig('mcloudplay_userName', '');
    var env = mcloud.getLocalConfig('environment', 'uat');
    var fs = require("fs");
    var cacheFilePath = "~/" + "project_list_" + uid + env + ".cache";
    var result = fs.readFileSync(cacheFilePath, "utf8");
    callback(result);
}

function saveProjectListCache(projectListJson, callback) {
    var uid = mcloud.getLocalConfig('mcloudplay_userName', '');
    var env = mcloud.getLocalConfig('environment', 'uat');
    var fs = require("fs");
    var cacheFilePath = "~/" + "project_list_" + uid + env + ".cache";
    var result = fs.writeFileSync(cacheFilePath, projectListJson);
    callback(result);
}

cache.getProjectListCache = getProjectListCache;
cache.saveProjectListCache = saveProjectListCache;
var exports = cache;