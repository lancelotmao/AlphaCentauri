var exports = {
  getUserName : function() {
    return 'test22';
  },

  getPassword : function() {
    return 'Pr0d1234';
  },
  
  getProjectId : function() {
    return '216203276'
  }
}