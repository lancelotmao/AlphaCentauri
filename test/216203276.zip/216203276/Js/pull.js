function getDownloadURL() {
  var env = mcloud.getLocalConfig('environment', 'uat');
  var isMAGEnabled = mcloud.getLocalConfig('enableMAG', "true");

  var tempURL;
  if (isMAGEnabled) {
    if (env == "pub") {
      tempURL = "http://w3m.huawei.com/mcloud/mag/ProxyForText/mcloudIDE_pub2/services/mcloud/ide/project/list/2999/1";
    } else if (env == "unicom") {
      tempURL = "http://haepub-gw.huawei.com/mcloud/umag/fg/ProxyForDownLoad/mcloudIDE_uc/services/mcloud/ide/project/list/2147483647/1";
    } else if (env == "uat") {
      tempURL = "http://w3m-beta2.huawei.com/mcloud/mag/ProxyForText/mcloud_ide_uat/services/mcloud/ide/project/list/2999/1";
    } else {
      tempURL = "http://w3m-alpha2.huawei.com/mcloud/mag/ProxyForText/mcloud_ide_sit/services/mcloud/ide/project/list/2999/1";
    }
  } else {
    if (env == "pub") {
      tempURL = "http://mcloud-pub2.huawei.com/mcloud/ide/services/mcloud/ide/project/list/2999/1";
    } else if (env == "unicom") {
      tempURL = "http://haepub-gw.huawei.com/mcloud/umag/fg/ProxyForDownLoad/mcloudIDE_uc/services/mcloud/ide/project/list/2147483647/1";
    } else if (env == "uat") {
      tempURL = "http://mcloudnkg-uat1.huawei.com/mcloud/ide/services/mcloud/ide/project/list/2999/1";
    } else {
      tempURL = "http://mcloudnkg-sit.huawei.com/mcloud/ide/services/mcloud/ide/project/list/2999/1";
    }
  }
  return tempURL;
}

var exports = {
    pull : function (callback) {
        console.log('Pulling Project List...');
        var projectListURL = getDownloadURL();
        mcloud.log('projectListURL:'+projectListURL);
        $.ajax({
           url :projectListURL,
           cache : true,  //default is false.
           async : true, //default is true.
           type : "GET", //default is get.
           timeout : 30000, // 30 seconds
           contentType : "application/x-www-form-urlencoded", //default is "application/x-www-form-urlencoded"
           beforeSend : function beforeSend(xhr){
               xhr.setRequestHeader("bundleVersion","1.1.2");
               xhr.setRequestHeader("publicKeyFlag","0");
               xhr.setRequestHeader("bundleName","LoginBundle");
               mcloud.log("beforeSend");
           },
           complete :function(xhr, status) {
               mcloud.log("complete " + status);
           },
           success :function(result , status, xhr) {
               mcloud.log(result);
               
               // set data to projects array
               var projects = JSON.parse(result).result;
               
               // notify listener
               callback(projects);
           },
           error :function(xhr , status, error) {
               console.log('failed to pull project list');
           },
        });
    }
}
