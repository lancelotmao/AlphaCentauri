var projectList = {};
var projectListCache;
function getProjectList(alwaysFromNetwork, identifier, callback) {
    if ("true" == alwaysFromNetwork){
        require('./projectListNetwork').downloadProjectList(identifier ,function(err, projectListJson) {
            if (err) {
              console.log("downloadProjectList: failed!");
              callback(null);
            } else {
                console.log("getProjectList: get project list from network success!");
                projectListCache.saveProjectListCache(projectListJson, function(result){
                    console.log("saveProjectListCache: result = " + result);
                });
                handleProjectListJson(projectListJson, identifier, callback);
            }
        });
    } else {
        projectListCache = require('./projectListCache');
        projectListCache.getProjectListCache(function(projectListJson) {
              if(projectListJson && "" != projectListJson){
                  console.log("getProjectList: get project list from cache file success! projectListJson = " + projectListJson);
                  handleProjectListJson(projectListJson, identifier, callback);
              } else {
                    require('./projectListNetwork').downloadProjectList(identifier ,function(err, projectListJson) {
                        if (err) {
                          console.log("downloadProjectList: failed!");
                          callback(null);
                        } else {
                            console.log("getProjectList: get project list from network success!");
                            projectListCache.saveProjectListCache(projectListJson, function(result){
                                console.log("saveProjectListCache: result = " + result);
                            });
                            handleProjectListJson(projectListJson, identifier, callback);
                        }
                    });
              }
        });
    }

}

function handleProjectListJson(projectListJson, identifier, callback){
    var resultParse;

    try {
      resultParse = JSON.parse(projectListJson);
    } catch(e) {
      resultParse = null;
      callback(null);
    }

    if (!resultParse) {
      console.log("handleProjectListJson: parse json failed!");
      callback(null);
      return;
    }

    if (resultParse.errorCode) {
      console.log("handleProjectListJson: parse result failed!");
      if (resultParse.errorCode == "1000") {
          var temp = require("./login.js");
          temp.setTag("mcloud");
          temp.autoLogin({
              success:function (argument) {
              getProjectList("true", identifier, callback );
              }
            });
      }
      callback(null);
      return;
    }

    var list = resultParse.result;
    var tempProjectList = [];
    for (var i = list.length - 1; i >= 0; i--) {
      var tempValue = {'projectName':list[i].name, 'projectId':list[i].id.toString()};
      tempProjectList.push(tempValue);
    }

    callback(tempProjectList);
}

projectList.getProjectList = getProjectList;

var exports = projectList;