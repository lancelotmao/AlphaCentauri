//
//  CameraBundle.h
//  CameraBundle
//
//  Created by chengxinqing on 15/5/7.
//  Copyright (c) 2015年 chengxinqing. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CameraBundle.
FOUNDATION_EXPORT double CameraBundleVersionNumber;

//! Project version string for CameraBundle.
FOUNDATION_EXPORT const unsigned char CameraBundleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CameraBundle/PublicHeader.h>


