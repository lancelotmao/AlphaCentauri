//
//  QuickResponseCode.h
//  QuickResponseCode
//
//  Created by hexiang on 15/2/2.
//  Copyright (c) 2015年 hexiang. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for QuickResponseCode.
FOUNDATION_EXPORT double QuickResponseCodeVersionNumber;

//! Project version string for QuickResponseCode.
FOUNDATION_EXPORT const unsigned char QuickResponseCodeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QuickResponseCode/PublicHeader.h>


