//
//  Login.h
//  Login
//
//  Created by lucaiguang on 15/1/30.
//  Copyright (c) 2015年 huawei. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Login.
FOUNDATION_EXPORT double LoginVersionNumber;

//! Project version string for Login.
FOUNDATION_EXPORT const unsigned char LoginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Login/PublicHeader.h>

//static NSString *publicKey = @"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDbf3N5eW+PgmaLBvDE23uMjdJW/eTrT8Hrx/fUvPcgeCoGqP8czJkFy2/XtDfWzaQJ1crPZTU/jGPPUIYeG7bWM61UHsMvDFos8F/RJhnreYML52MwRE55aD8AC0UOs0UxGBtT0ByG874qM8nOanN2Homy/hsJjj/HzQZuQ/vWUQIDAQAB";


