//
//  EDMBundle.h
//  EDMBundle
//
//  Created by terry on 15/5/8.
//  Copyright (c) 2015年 huawei. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for EDMBundle.
FOUNDATION_EXPORT double EDMBundleVersionNumber;

//! Project version string for EDMBundle.
FOUNDATION_EXPORT const unsigned char EDMBundleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EDMBundle/PublicHeader.h>


